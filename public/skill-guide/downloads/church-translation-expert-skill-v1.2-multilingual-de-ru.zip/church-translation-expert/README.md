# 召會翻譯專家 Skill Pack v1.1

## 本版新增
本版已整合 Google Drive「GPT多語翻譯及對話助手」相關資料中的正式中英語料。

- 高品質中英句對：959 筆
- 關鍵術語例句：45 筆
- 重要固定詞彙：20 筆
- 待人工複核：80 筆（刻意不納入主語料）

## 檔案
- `SKILL.md`
- `references/glossary.csv`
- `references/official-important-terms.csv`
- `references/key-term-examples.csv`
- `references/official-bilingual-corpus.csv`
- `references/translation-rules.md`
- `references/conversation-mode.md`

## 設計原則
Skill 會先查固定詞，再查關鍵術語例句，最後才使用完整雙語 corpus。
這樣可兼顧術語穩定與自然句型。

## 後續建議
1. 人工複核原活頁簿中的「待複核」80筆。
2. 逐步加入泰文、印尼文等正式術語欄位。
3. 若有合法可使用的恢復本完整經文，可另外建立專門 Bible reference，不應混入一般 corpus。


## v1.2 多語資料庫新增
已新增英德與英俄正式平行語料。

- 英德：38 個結構對齊綱要區塊
- 英俄：35 個結構對齊綱要區塊
- 中英德俄核心術語表：14 筆
- 同時保留四份完整抽取綱要文字，供模型做長上下文參考

注意：本版只把可穩定結構對齊的內容標記為正式平行語料；未經對齊的其他篇不會被冒充成已驗證句對。
